# Night Owl Theme

> Night Owl theme for VS Code.

![Preview](images/preview.gif)

# Installation

1.  Install [Visual Studio Code](https://code.visualstudio.com/)
2.  Launch Visual Studio Code
3.  Choose **Extensions** from menu
4.  Search for `night-owl`
5.  Click **Install** to install it
6.  Click **Reload** to reload the Code
7.  File > Preferences > Color Theme > **Night Owl**

-[ ] check check 12 12
-[ ] check check 12 12

Heading 1
========

Heading 2
--------------

### Heading 3
